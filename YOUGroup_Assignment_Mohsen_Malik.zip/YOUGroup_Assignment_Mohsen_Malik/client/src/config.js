const config = {
  serverBaseUrl: "http://localhost:5000/api/",
  serverVersion: "v1/"
}

const apis = {
  getTours: config.serverBaseUrl + config.serverVersion + "tours/",
  getTourById: config.serverBaseUrl + config.serverVersion + "tour/",
}

module.exports = {apis, config}