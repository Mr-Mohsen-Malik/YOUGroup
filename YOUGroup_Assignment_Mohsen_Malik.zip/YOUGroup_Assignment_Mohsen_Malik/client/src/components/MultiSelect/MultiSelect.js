import React, { useState, useEffect } from "react";
import ReactMultiSelectCheckboxes from "react-multiselect-checkboxes";

import options from "./data";

const MultiSelect = () => {
  const [selectedOptions, setSelectedOptions] = useState([]);

  return (
    <ReactMultiSelectCheckboxes
      options={options}
      onChange={onChange}
      setState={setSelectedOptions}
    />
  );
};

function onChange(value, event) {
  console.log(value);
  console.log(event);
  if (event.action === "select-option" && event.option.value === "*") {
    this.setState(this.options);
  } else if (event.action === "deselect-option" && event.option.value === "*") {
    this.setState([]);
  } else if (event.action === "deselect-option") {
    this.setState(value.filter((o) => o.value !== "*"));
  } else if (value.length === this.options.length - 1) {
    this.setState(this.options);
  } else {
    this.setState(value);
  }
}

export default MultiSelect;
