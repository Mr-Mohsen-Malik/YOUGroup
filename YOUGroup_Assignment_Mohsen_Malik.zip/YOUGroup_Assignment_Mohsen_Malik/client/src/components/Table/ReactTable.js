import React, { useState, useEffect } from "react";
import { useTable, useSortBy } from 'react-table'
import Pagination from "@material-ui/lab/Pagination";
import ReactMultiSelectCheckboxes from "react-multiselect-checkboxes";
import Select from 'react-select'
import { Card, CardBody, CardHeader, CardTitle, Table, Row, Col } from "reactstrap";
import TourSrvc from "../../services/tourService";

const ReactTableComponent = (props) => {

  //#region declaration of variable
  const [searchTitle, setSearchTitle] = useState("");
  const [page, setPage] = useState(1);
  const [count, setCount] = useState(0);
  const [pageSize, setPageSize] = useState(5);
  const pageSizes = [5, 10, 20, 50];
  const [sortColumn, setSortColumn] = useState({});
  const [sortby, setSortby] = useState("");
  const [sortOrder, setSortOrder] = useState(1);
  const [loadingData, setLoadingData] = useState(true);
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [options, setOptions] = useState([]);
  //#endregion declaration of variable

  //#region implementation of functions
  //filter/sorting functions
  const resetFilters = () => {
    setSearchTitle("");
    setPage(1);
    setCount(0);
    setPageSize(5);
    setSortColumn({});
    setSortby("");
    setSortOrder(1);
    setLoadingData(true);
    setData([]);
    setColumns([]);
    setSelectedOptions([]);
    setOptions([]);
  };
  const findByTitle = () => {
    setPage(1);
    retrieveTours();
  };
  const handlePageChange = (event, value) => {
    setPage(value);
  };
  const handlePageSizeChange = (event) => {
    setPageSize(event.target.value);
    setPage(1);
  };
  const handleSortChange = (column) => {
    if (sortColumn && sortColumn != {} && (sortColumn != column) && column.isSorted) {
      setSortColumn(column);

    }
    else if (sortColumn && sortColumn != {} && (sortColumn.isSortedDesc != column.isSortedDesc) && column.isSorted) {
      column.isSortedDesc = sortColumn.isSortedDesc;

    }
    if (column.Header == sortColumn.Header) {
      return (
        sortColumn.isSorted
          ? sortColumn.isSortedDesc
            ? ' 🔽'
            : ' 🔼'
          : ''
      )
    }
    return (
      column.isSorted
        ? column.isSortedDesc
          ? ' 🔽'
          : ' 🔼'
        : ''
    )

  };
  const onChange = (value, event) => {
    setSelectedOptions(value)
  }
  const onFilterChange = (value, event) => {
    sortColumn.Header = value.value
    setSortby(value.value);
  }
  const onOrderChange = (value, event) => {
    sortColumn.isSortedDesc = value.value
    setSortOrder(value.value)
  }
  const onChangeSearchTitle = (e) => {
    const searchTitle = e.target.value;
    setSearchTitle(searchTitle);
  };

  //api functions
  const retrieveTours = () => {
    TourSrvc.retrieveTours(selectedOptions, searchTitle, page, pageSize, sortColumn, sortby, sortOrder)
      .then(response => {
        const { data, totalPages, totalCount, columns } = response;
        if (data['length'] > 0) {
          setColumns(Object.keys(data[0]).map(key => ({
            Header: key,
            accessor: key,
          })));

          setOptions(Object.keys(columns).map((key, idx) => ({
            "id": idx,
            "value": key,
            "label": key
          })));
        }
        setData(data);
        setCount(totalPages);
        setLoadingData(false);
      })
  }
  useEffect(retrieveTours, [page, pageSize]);
  //#endregion implementation of functions

  //#region init the table parameters
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({
    columns,
    data: data,
  },
    useSortBy);
  //#endregion init the table parameters
  return (
    <div>
      {/* here you check if the state is loading otherwise if you wioll not call that you will get a blank page because the data is an empty array at the moment of mounting */}
      {loadingData ? (
        <p>Fetching table data Please wait...</p>
      ) : (
        <Card>
          <CardHeader>
            <Row>
              <Col className="text-left" sm="6">
                <h5 className="card-category">{props.title}</h5>
                <CardTitle tag="h2">Table</CardTitle>
              </Col>
            </Row>
            <Row>
              <Col sm="4">
                <div className="input-group mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search..."
                    value={searchTitle}
                    onChange={onChangeSearchTitle}
                  />
                  <div className="input-group-append">
                    <button
                      className="btn btn-outline-secondary"
                      type="button"
                      onClick={findByTitle}
                    >
                      Apply filters
                    </button>
                  </div>
                </div>
              </Col>

              <Col sm="2">
                <div style={{ color: "black" }}>
                  <Select options={selectedOptions.length > 0 ? selectedOptions : options}
                    onChange={onFilterChange}
                    placeholder="Filter by" />
                </div>

              </Col>
              <Col sm="2">
                <div style={{ color: "black" }}>
                  <Select options={[{
                    "id": 1,
                    "value": 1,
                    "label": "Asc"
                  },
                  {
                    "id": -1,
                    "value": -1,
                    "label": "Desc"
                  }]}
                    onChange={onOrderChange}
                    placeholder="OrderBy" />
                </div>
              </Col>
              <Col sm="3">
                <div style={{ color: "black" }}>
                  <ReactMultiSelectCheckboxes
                    className="dropdown-basic-button"
                    placeholder="Type..."
                    options={options}
                    value={selectedOptions}
                    onChange={onChange}
                    setState={setSelectedOptions}
                  />
                </div>
              </Col>
            </Row>
            <Row>
              <Col sm="6">
                {"Items per Page: "}
                <select onChange={handlePageSizeChange} value={pageSize}>
                  {pageSizes.map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>

                <Pagination
                  className="my-3"
                  count={count}
                  page={page}
                  siblingCount={1}
                  boundaryCount={1}
                  variant="outlined"
                  shape="rounded"
                  onChange={handlePageChange}
                />
              </Col>
            </Row>
          </CardHeader>
          <CardBody>
            <Table
              className="tablesorter"
              {...getTableProps()}
            >
              <thead className="text-primary">
                {headerGroups.map((headerGroup) => (
                  <tr {...headerGroup.getHeaderGroupProps()}>
                    {headerGroup.headers.map((column) => (
                      <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                        {column.render("Header")}
                        <span>
                          {handleSortChange(column)}
                        </span>
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>
              <tbody {...getTableBodyProps()}>
                {rows.map((row, i) => {
                  prepareRow(row);
                  return (
                    <tr {...row.getRowProps()}>
                      {row.cells.map((cell) => {
                        return (
                          <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          </CardBody>
        </Card>
      )}
    </div>
  );
};


export default ReactTableComponent;
