import React, { useState, useEffect } from "react";
import { Line } from "react-chartjs-2";
import Select from 'react-select'
import TourSrvc from "../../services/tourService";
import ReactMultiSelectCheckboxes from "react-multiselect-checkboxes";

// reactstrap components
import { Card, CardHeader, CardBody, CardTitle, Row, Col, } from "reactstrap";

//#region color array for multi lines
var colorArray = ['#FF6633', '#FFB399', '#FF33FF', '#FFFF99', '#00B3E6',
  '#E6B333', '#3366E6', '#999966', '#99FF99', '#B34D4D',
  '#80B300', '#809900', '#E6B3B3', '#6680B3', '#66991A',
  '#FF99E6', '#CCFF1A', '#FF1A66', '#E6331A', '#33FFCC',
  '#66994D', '#B366CC', '#4D8000', '#B33300', '#CC80CC',
  '#66664D', '#991AFF', '#E666FF', '#4DB3FF', '#1AB399',
  '#E666B3', '#33991A', '#CC9999', '#B3B31A', '#00E680',
  '#4D8066', '#809980', '#E6FF80', '#1AFF33', '#999933',
  '#FF3380', '#CCCC00', '#66E64D', '#4D80CC', '#9900B3',
  '#E64D66', '#4DB380', '#FF4D4D', '#99E6E6', '#6666FF'];
//#endregion color array for multi lines

const ChartComponent = (props) => {

  //#region declaration of variable
  const [rawChartData, setrawChartData] = useState({});
  const [id, setId] = useState(1);
  const [ids, setIds] = useState([]);
  const [loadingData, setLoadingData] = useState(true);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [options, setOptions] = useState([]);
  //#endregion declaration of variable

  //#region implementation of functions
  const onChange = (value, event) => {
    setSelectedOptions(value)
  }
  const onIdChange = (value, event) => {
    setId(value.value)
  }
  const onfilterChange = () => {
    retrieveTour(id,selectedOptions );
  };
  //chart options
  const chartOptions = {
    maintainAspectRatio: false,
    legend: {
      display: false,
    },
    tooltips: {
      backgroundColor: "#f5f5f5",
      titleFontColor: "#333",
      bodyFontColor: "#666",
      bodySpacing: 4,
      xPadding: 12,
      mode: "nearest",
      intersect: 0,
      position: "nearest",
    },
    responsive: true,
    scales: {
      yAxes: [
        {
          barPercentage: 1.6,
          gridLines: {
            drawBorder: false,
            color: "rgba(29,140,248,0.0)",
            zeroLineColor: "transparent",
          },
          ticks: {
            suggestedMin: 60,
            suggestedMax: 125,
            padding: 20,
            fontColor: "#9a9a9a",
          },
        },
      ],
      xAxes: [
        {
          barPercentage: 1.6,
          gridLines: {
            drawBorder: false,
            color: "rgba(29,140,248,0.1)",
            zeroLineColor: "transparent",
          },
          ticks: {
            padding: 20,
            fontColor: "#9a9a9a",
          },
        },
      ],
    },
  }
  //api functions
  const retrieveTours = () => {
    var arr = [{
      "id": 1,
      "value": 'id',
      "label": 'id'
    }];
    TourSrvc.retrieveTours(arr, null, -1)
      .then(response => {
        const { data, columns } = response;

        if (data['length'] > 0) {
          setIds(data.map(row => ({
            "id": row.id,
            "value": row.id,
            "label": row.id
          })))


          setOptions(Object.keys(columns).map((key, idx) => ({
            "id": idx,
            "value": key,
            "label": key
          })));
          retrieveTour(data[0].id, selectedOptions);
        }
      })
  }
  const retrieveTour = (id, selectedOptions) => {
    setId(id);
    setLoadingData(true);

    setSelectedOptions(selectedOptions);
    TourSrvc.retrieveTourById(id, selectedOptions)
      .then(response => {
        setrawChartData(response);
        setLoadingData(false);
      })
  }
  useEffect(retrieveTours, []);
  //#endregion implementation of functions

  return (
    <div>
      {loadingData ? (
        <p>Fetching chart data Please wait...</p>
      ) : (
        <Card className="card-chart">
          <CardHeader>
            <Row>
            
              <Col className="text-left" sm="3">
                <h5 className="card-category">{props.title}</h5>
                <CardTitle tag="h2">Time Series for: {id}</CardTitle>
              </Col>


              <Col className="text-left" sm="3">
                    <button
                      className="btn btn-outline-secondary"
                      type="button"
                      onClick={onfilterChange}
                    >
                      Apply filters
                    </button>
              </Col>
              <Col sm="2">
                <div style={{ color: "black" }}>
                  <Select options={ids}
                    placeholder="Product ID"
                    onChange={onIdChange} />
                </div>
              </Col>
              <Col sm="2">
                <div style={{ color: "black" }}>
                  <ReactMultiSelectCheckboxes
                    className="dropdown-basic-button"
                    placeholder="Type..."
                    options={options}
                    value={selectedOptions}
                    onChange={onChange}
                    setState={setSelectedOptions}
                  />
                </div>
              </Col>
            </Row>
          </CardHeader>
          <CardBody>
            <div className="chart-area">
              <Line
                data={(canvas) => {
                  let ctx = canvas.getContext("2d");
                  let gradientStroke = ctx.createLinearGradient(0, 230, 0, 50);

                  gradientStroke.addColorStop(1, "rgba(29,140,248,0.2)");
                  gradientStroke.addColorStop(0.4, "rgba(29,140,248,0.0)");
                  gradientStroke.addColorStop(0, "rgba(29,140,248,0)"); //blue colors

                  var _labels = rawChartData['data']['date']
                  var _datasets = [];
                  var indx = 0;
                  for (var col in rawChartData['data']) {
                    if (col != 'date') {
                      _datasets.push({
                        label: col,
                        data: rawChartData['data'][col],
                        fill: true,
                        borderColor: colorArray[indx++],
                        backgroundColor: gradientStroke,
                        borderDash: [],
                      }
                      )
                    }
                  }
                  return {
                    labels: _labels,
                    datasets: _datasets,
                  };
                }}
                options={chartOptions}
              />
            </div>
          </CardBody>
        </Card>
      )}
    </div>
  )
}

export default ChartComponent;