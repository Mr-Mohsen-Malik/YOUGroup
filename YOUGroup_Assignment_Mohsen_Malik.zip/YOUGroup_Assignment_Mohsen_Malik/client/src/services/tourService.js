import { apis } from "../config";

const TourSrvc = {};

TourSrvc.retrieveTours = (selectedOptions, searchTitle = null, page = 1, pageSize = 5, sortColumn = {id:1}, sortby = "id" , sortOrder = 1) => {
  const params = getRequestParams(selectedOptions, searchTitle, page, pageSize, sortColumn, sortby, sortOrder);
  // //fecting data 
  // POST request using fetch inside useEffect React hook
  const requestOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  };

  return fetch(apis.getTours, requestOptions)
    .then(response => response.json());
}

TourSrvc.retrieveTourById = (id, selectedOptions) => {
  const params = {};
  const defaultSelectedColumn1 = "date";
  const defaultSelectedColumn2 = "price";
  if (selectedOptions && selectedOptions.length > 0 ) {
    params["selectedColumns"] = JSON.stringify([defaultSelectedColumn1, ...(selectedOptions.map(option => option.value))]);
  } else {
    params["selectedColumns"] = JSON.stringify([defaultSelectedColumn1, defaultSelectedColumn2]);
  }
  // //fecting data 
  // POST request using fetch inside useEffect React hook
  const requestOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  };

  return fetch(apis.getTourById + id , requestOptions)
    .then(response => response.json());
}

//helper functions
const getRequestParams = (selectedOptions, searchTitle, page, pageSize, sortColumn, sortby, sortOrder) => {
  let params = {};

  if (searchTitle) {
    params["text"] = searchTitle;
  }
  if (page) {
    params["page"] = page;
  }
  if (pageSize) {
    params["size"] = pageSize;
  }
  if (sortColumn) {
    params["sortby"] = sortby;
    params["sortOrder"] = sortOrder;
  }
  if (selectedOptions) {
    params["selectedColumns"] = JSON.stringify(selectedOptions.map(option => option.value));
  }
  return params;
};


export default TourSrvc;