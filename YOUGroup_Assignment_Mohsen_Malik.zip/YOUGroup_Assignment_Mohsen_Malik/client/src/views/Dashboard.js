import React from "react";
import ChartComponent from "../components/Chart/Chart";
import ReactTableComponent from "../components/Table/ReactTable";

// reactstrap components
import {
  Row,
  Col,
} from "reactstrap";

function Dashboard(props) {
  return (
    <>
      <div className="content">
      <Row>
          <Col md="12">
            <ChartComponent  />
          </Col>
        </Row>
        <Row>
          <Col md="12">
            <ReactTableComponent  />
          </Col>
        </Row>
        
      </div>
    </>
  );
}

export default Dashboard;
