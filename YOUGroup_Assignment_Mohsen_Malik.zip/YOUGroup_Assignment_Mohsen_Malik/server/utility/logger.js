//global

cLog = (...args) => {
    console.log(`========Logging Start======== \n`);
    args.forEach((element, i) => {
      console.log(`------${(i + 1)}/${args.length}------`, "\n", element);
    });
    console.log(`========Logging End======== \n`);
}

dLog = (isLog , ...args) => {
  if (isLog) {
    cLog(...args);
  }
}