const { csvData, colNamesForChart } = require("../config");
const csv = require('csvtojson');

const tour = {};

//#region function to retrieve all data
tour.getTourList = (req, res) => {

  //#region parsing filter parameters
  var page_size = req.body.size ?? 10;
  var page_number = req.body.page ?? 1;
  var searchText = req.body.text;
  var sortby = req.body.sortby ?? "id";
  var sortOrder = req.body.sortOrder ?? 1;
  var selectedColumns = req.body.selectedColumns;
  //#endregion parsing filter parameters

  //#region init response body
  let resultSet = {};
  resultSet.totalCount = 0;
  resultSet.totalPages = 0;
  resultSet.columns = {};
  resultSet.data = [];
  //#endregion init response body

  //reading csv
  csv()
    .fromFile(csvData.path)
    .then((jsonObj) => {

      //#region filtering data row wise
      if (searchText) {
        jsonObj = jsonObj.filter(row => JSON.stringify(row).includes(searchText));
      }
      //#endregion  filtering data row wise

      if (jsonObj.length > 0) {
        //sorting on column
        jsonObj.sort(dynamicSort(sortby, sortOrder));


        //data for pagination/filter/totalColumns
        resultSet.totalCount = jsonObj.length;
        resultSet.totalPages = Math.ceil(jsonObj.length / page_size);
        if(page_number > 0)
        resultSet.columns = jsonObj[0];
        else 
        resultSet.columns = colNamesForChart;

        //data after pagination
        if (page_number > 0)
          jsonObj = jsonObj.slice((page_number - 1) * page_size, page_number * page_size);
        else {
          var temp = [];
          jsonObj = jsonObj.filter((row) => {
            if (!temp.includes(row.id)) {
              temp.push(row.id);
              return true;
            }
            return false;
          });
          console.log("temp", temp)
        }



        //#region filtering data column wise
        if (selectedColumns && selectedColumns['length'] > 0 && JSON.parse(selectedColumns).length > 0) {
          let columns = JSON.parse(selectedColumns);
          jsonObj = jsonObj.map(row => {
            let newObj = {};
            for (var col in row) {
              if (columns.includes(col)) newObj[col] = row[col];
            }
            return newObj;
          });
        }
        //#endregion  filtering data column wise

        //final resultset
        resultSet.data = jsonObj;
      }
      res.json(resultSet)
    })
}
//#endregion function to retrieve all data

//#region function to retrieve data by id
tour.getTourById = (req, res) => {

  //#region parsing filter parameters
  var product_id = req.params.id;
  if (product_id) {
    var selectedColumns = req.body.selectedColumns;
    //#endregion parsing filter parameters

    //#region init response body
    let resultSet = {};
    resultSet.totalCount = 0;
    resultSet.columns = {};
    resultSet.data = [];
    //#endregion init response body

    //reading csv
    csv()
      .fromFile(csvData.path)
      .then((jsonObj) => {
        //#region finding row with id
        jsonObj = jsonObj.filter(row => row['id'] == product_id);
        //#endregion finding row with id

        if (jsonObj) {
          //data for pagination/filter/totalColumns
          resultSet.columns = jsonObj[0];
          let newObj = {};

          //#region filtering data column wise
          if (selectedColumns && selectedColumns['length'] > 0 && JSON.parse(selectedColumns).length > 0) {
            let columns = JSON.parse(selectedColumns);
            jsonObj.forEach(row => {
              for (var col in row) {
                if (columns.includes(col)) {
                  if (!newObj[col]){
                    newObj[col] = [];
                    global.cLog(col, newObj, newObj[col], !newObj[col])
                  }
                  global.cLog(row[col], newObj)
                  newObj[col].push(row[col]);
                }
              }
              // return newObj;
            });
          }
          //#endregion  filtering data column wise

          //final resultset
          resultSet.totalCount = jsonObj.length;
          resultSet.data = newObj;
        }
        res.json(resultSet)
      })
  }
}
//#endregion function to retrieve data by id

//#region function for sorting data on select column
function dynamicSort(property, _sortOrder) {
  var sortOrder = 1 * _sortOrder;
  if (property[0] === "-") {
    sortOrder = -1;
    property = property.substr(1);
  }
  return function (a, b) {
    var aVal = parseFloat(a[property]);
    var bVal = parseFloat(b[property]);

    if (a[property] && a[property].includes('-') && b[property] && b[property].includes('-')) {
      aVal = new Date(a[property]);
      bVal = new Date(b[property]);
      result = (aVal < bVal) ? -1 : (aVal > bVal) ? 1 : 0;
    } else {
      var result = 0;
      if (!aVal) {
        aVal = a[property];
        bVal = b[property];
        result = (aVal < bVal) ? -1 : (aVal > bVal) ? 1 : 0;
      } else {
        result = parseInt(aVal - bVal);
      }
    }
    return result * sortOrder;

  }
}
//#endregion function for sorting data on select column

module.exports = tour;