var express = require('express');
var tourSrvc = require('./services/tour');

const setRoutes = (app) => {

    const router = express.Router();

    router.route("/tours").post( (req, res) => {
        tourSrvc.getTourList(req, res);
    });
    router.route("/tour/:id").post( (req, res) => {
        tourSrvc.getTourById(req, res);
    });
    app.use('/api/v1', router);
}

module.exports = setRoutes;